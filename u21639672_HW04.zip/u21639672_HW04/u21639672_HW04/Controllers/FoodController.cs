﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using u21639672_HW04.ViewModels;

namespace u21639672_HW04.Controllers
{
    public class FoodController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public ActionResult Food(Food food)
        {
            string foodType = food.FoodType;
            int foodSupp = food.foodSupp;
            return RedirectToAction("Food");
        }
    }
}
