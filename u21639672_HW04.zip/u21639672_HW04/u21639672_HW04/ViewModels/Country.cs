﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW04.ViewModels
{
    public class Country
    {
        public string countryName { get; set; }
        public string continent { get; set; }
        public int population { get; set; }

        public Country()
        {
            countryName = "Nothing";
            continent = "Nowhere";
            population = -1;
        }

        public Country(int countryID, string countryName, string continent, int population)
        {
            this.countryName = countryName;
            this.continent = continent;
            this.population = population;
        }
    }
}
