﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW04.ViewModels
{
    public class CountryData:Country
    {
        public double avgPopulation { get; set; } 
            
        public CountryData()
        {
            double avgPopulation = -1.1; 
        }

        public CountryData(double avgPopulation)
        {
            this.avgPopulation = avgPopulation;
        }

        public double AveragePopulation()
        {
            Country country = new Country();
            avgPopulation = (country.population) / 7.97;
            return avgPopulation;
        }
    }
}
