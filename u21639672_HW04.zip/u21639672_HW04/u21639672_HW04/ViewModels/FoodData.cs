﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW04.ViewModels
{
    public class FoodData:Food
    {
        public double avgFoodSupply { get; set; }

        public FoodData()
        {
            double avgFoodSupply= -1.1;
        }

        public FoodData(double avgFoodSupply)
        {
            this.avgFoodSupply = avgFoodSupply;
        }

        public double AverageFoodSupply()
        {
            Food Food = new Food();
            Country country = new Country();
            avgFoodSupply = (Food.foodSupp) / country.population;
            return avgFoodSupply;
        }
    }
}
