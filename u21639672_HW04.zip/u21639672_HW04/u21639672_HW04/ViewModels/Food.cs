﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW04.ViewModels
{
    public class Food
    {
        public string FoodType { get; set; }
        public int foodSupp { get; set; }

        public Food()
        {
            FoodType = "Nothing";
            foodSupp = 1;
        }

        public Food(string foodType, int foodSupp)
        {
            FoodType = foodType;
            this.foodSupp = foodSupp;
        }


    }
}
